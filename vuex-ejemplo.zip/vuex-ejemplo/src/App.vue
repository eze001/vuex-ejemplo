<template>
  <div id="app">
    <Peliculas genero="comedia"/>
    <Peliculas genero="familia"/>
  </div>
</template>

<script>
import Peliculas from './components/Peliculas.vue'

export default {
  name: 'App',
  components: {
    Peliculas
  }
}
</script>
