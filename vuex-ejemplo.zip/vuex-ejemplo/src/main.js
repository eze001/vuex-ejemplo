import Vue from 'vue'
import Vuex from 'vuex'
import App from './App.vue'

Vue.config.productionTip = false

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {
    peliculas:[
      { id: 1, titulo: 'Una Pareja de Idiotas', genero: 'comedia'},
      { id: 2, titulo: 'Mentiroso, Mentiroso', genero: 'comedia'},
      { id: 3, titulo: 'Loca Academia de Policia', genero: 'comedia'},
      { id: 4, titulo: 'Las Tortugas Ninjas', genero: 'familia'},
      { id: 5, titulo: 'Los Croods', genero: 'familia'},
      { id: 6, titulo: 'La Era del Hilelo', genero:'familia'},
      { id: 7, titulo: 'Condorito', genero: 'comedia'},
      { id: 8, titulo: 'El Rey Leon', genero: 'familia'}
    ]
  },
})

new Vue({
  store,
  render: h => h(App),
}).$mount('#app')
