<template>
    <div id="Peliculas">
        <h2>Peliculas del genero: {{genero}}</h2>
        <ul>
            <li v-for="peli in ListaPelis" :key="peli.id">{{peli.titulo}}</li>
        </ul>
    </div>
</template>

<script>
    export default {
        name:"Peliculas",
        props:{
            genero:String
        },
        computed:{
            ListaPelis(){
                return this.$store.state.peliculas.filter(pelicula => pelicula.genero == this.genero);
            }
        }
    }
</script>